package model.world;

public enum Direction {
	UP, DOWN, LEFT, RIGHT
}
